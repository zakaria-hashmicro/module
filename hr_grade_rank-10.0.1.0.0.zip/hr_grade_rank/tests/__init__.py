# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from . import test_hr_grade_rank
